//Daniela Acuña Sánchez
var total = 1;
var array1 = [2,3,4,6];

for (var f=0;f<array1.length;f++){
    if(array1[f]!=0){
      total = (array1[f]*total);
    }
}
alert("Resultado multiplicacion del array 1 es:"+total);

var total = 1;
var array2 = [123,67,890,4];

for (var f=0;f<array2.length;f++){
    if(array2[f]!=0){
      total = (array2[f]*total);
    }
}
alert("Resultado multiplicacion del array 2 es:"+total);

var total = 1;
var array3 = [2,3,7,9,4,5,6,9,12];

for (var f=0;f<array3.length;f++){
    if(array3[f]!=0){
      total = (array3[f]*total);
    }
}
alert("Resultado multiplicacion del array 3 es:"+total);



