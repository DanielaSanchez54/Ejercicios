//Daniela Acuña Sánchez
var n = parseFloat(prompt("Ingrese un número:"));
var t=1;

for(var i=1; i<=n;i++){
	t=t*i;
  alert(i+"!="+t);
}

