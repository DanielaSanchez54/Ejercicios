#Daniela Acuña Sánchez
array = [98,32,78,11,57];
mayor=array[0];
for x in (0..4)
  if array[x]>mayor
    puts i
    mayor=array[x];
  end
end
print mayor;
