#Daniela Acuña Sánchez
max=6
array= [1,3,5,3,5,2,2,4,2,2]
vector=[]

for i in 0..max
  vector[i]=0
end

for i in 0..array.length
  for j in 0..vector.length
    if array[i]==j
      vector[j]=vector[j]+1
    end
  end
end

puts array.inspect

i=0
while i<max
  print "#{i} "
  
  f=vector[i]
  j=0
  while j<f
    print "*"
    j=j+1
  end
  puts "\n"
  i=i+1
end