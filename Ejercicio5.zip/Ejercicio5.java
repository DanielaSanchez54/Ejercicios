
class Main {
  public static void main(String[] args) {
    //Nombre: Daniela Acuña Sánchez
       int [] myarray = {1,2,4,6,8,3,2,2,5,3,1};
       int [] contador = new int [myarray.length];
       int mayor=contador[0];
       int ocurrencia=0;
       int numero=0;

       for(int i=0;i<myarray.length;i++){
            contador[myarray[i]] +=1; 
       }
       
       for (int i=0;i<contador.length;i++){
   
            if(contador[i]>mayor){
            mayor=contador[i];
            numero=myarray[i-1];
            ocurrencia=mayor;
            }
    
        }
        System.out.println("Ocurrencia:"+ocurrencia);  
        System.out.println("Número:"+numero);


  }
}